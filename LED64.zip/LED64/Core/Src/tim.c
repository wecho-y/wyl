/**
  ******************************************************************************
  * @file    tim.c
  * @brief   This file provides code for the configuration
  *          of the TIM instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "tim.h"
#include "led.h"
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

TIM_HandleTypeDef htim3;
extern uint8_t currentDight,remainingTime,currentState;
/* TIM3 init function */
void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 7999;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* tim_baseHandle)
{

  if(tim_baseHandle->Instance==TIM3)
  {
  /* USER CODE BEGIN TIM3_MspInit 0 */

  /* USER CODE END TIM3_MspInit 0 */
    /* TIM3 clock enable */
    __HAL_RCC_TIM3_CLK_ENABLE();
  /* USER CODE BEGIN TIM3_MspInit 1 */
    HAL_NVIC_SetPriority(TIM3_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(TIM3_IRQn);
  /* USER CODE END TIM3_MspInit 1 */
  }
}

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* tim_baseHandle)
{

  if(tim_baseHandle->Instance==TIM3)
  {
  /* USER CODE BEGIN TIM3_MspDeInit 0 */

  /* USER CODE END TIM3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM3_CLK_DISABLE();
  /* USER CODE BEGIN TIM3_MspDeInit 1 */

  /* USER CODE END TIM3_MspDeInit 1 */
  }
}
void My_Delay_ms(uint16_t nms)
{
	uint16_t counter=0;
	__HAL_TIM_SET_COUNTER(&htim3,0);
	HAL_TIM_Base_Start(&htim3);
	do
	{
		counter=__HAL_TIM_GET_COUNTER(&htim3);
	}
	while(counter<nms);
	HAL_TIM_Base_Stop(&htim3);
}

void HAL_TIM_PeriodElapsedCallback (TIM_HandleTypeDef *htim)
{
	
	if(htim==&htim3)
	{

				if(remainingTime == 0) {
						switch(currentState) {
             case 0://��� 
                    HAL_GPIO_WritePin(GPIOB, RLED_Pin, GPIO_PIN_RESET);
                    HAL_GPIO_WritePin(GPIOB, GLED_Pin, GPIO_PIN_SET);
                    HAL_GPIO_WritePin(GPIOB, RLED1_Pin, GPIO_PIN_SET);
                    HAL_GPIO_WritePin(GPIOB, GLED3_Pin, GPIO_PIN_RESET);
                    remainingTime = 15;
                    currentState = 1;
                    break;
                    
             case 1: //�Ƶ�
                    HAL_GPIO_WritePin(GPIOB, GLED_Pin, GPIO_PIN_RESET);
                    HAL_GPIO_WritePin(GPIOB, YLED_Pin, GPIO_PIN_SET);
                    HAL_GPIO_WritePin(GPIOB, YLED2_Pin, GPIO_PIN_SET);
                    HAL_GPIO_WritePin(GPIOB, RLED1_Pin, GPIO_PIN_RESET);
                    remainingTime = 4;
                    currentState = 2;
                    break;
                    
            case 2://�̵�
                    HAL_GPIO_WritePin(GPIOB, YLED_Pin, GPIO_PIN_RESET);
                    HAL_GPIO_WritePin(GPIOB, RLED_Pin, GPIO_PIN_SET);
                    HAL_GPIO_WritePin(GPIOB, YLED2_Pin, GPIO_PIN_RESET);
                    HAL_GPIO_WritePin(GPIOB, GLED3_Pin, GPIO_PIN_SET);
                    remainingTime = 15;
                    currentState = 0;
                    break;
            }
        }
		
		
//		static uint16_t counter = 0;
//		counter ++;
//		
//		if(counter >= 1000)
//		{
//			counter = 0;
			if(remainingTime > 0)
			{
				remainingTime --;
			}
//		}
		
	//Led_Down_Interrupt();
	}
}
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

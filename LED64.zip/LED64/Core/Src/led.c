#include "led.h"


extern uint8_t currentDight,remainingTime,currentState;
void Led_Init(GPIO_TypeDef *GPIOLed)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
	if (GPIOLed == GPIOA) 
		{
        __HAL_RCC_GPIOA_CLK_ENABLE();
    } 
	else if (GPIOLed == GPIOB) 
		{
        __HAL_RCC_GPIOB_CLK_ENABLE();
    } 
	else if (GPIOLed == GPIOC) 
		{
        __HAL_RCC_GPIOC_CLK_ENABLE();
    }

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, RLED_Pin|YLED_Pin|GLED_Pin|RLED1_Pin|YLED2_Pin|GLED3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PAPin PAPin PAPin */
  GPIO_InitStruct.Pin = RLED_Pin|YLED_Pin|GLED_Pin|RLED1_Pin|YLED2_Pin|GLED3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);	
}

void Led_ON()
{
	if(remainingTime == 0) {
       switch(currentState) {
             case 0: 
                    HAL_GPIO_WritePin(GPIOB, RLED_Pin, GPIO_PIN_RESET);
                    HAL_GPIO_WritePin(GPIOB, GLED_Pin, GPIO_PIN_SET);
                    remainingTime = 15;
                    currentState = 1;
                    break;
                    
             case 1: 
                    HAL_GPIO_WritePin(GPIOB, GLED_Pin, GPIO_PIN_RESET);
                    HAL_GPIO_WritePin(GPIOB, YLED_Pin, GPIO_PIN_SET);
                    remainingTime = 3;
                    currentState = 2;
                    break;
                    
            case 2:
                    HAL_GPIO_WritePin(GPIOB, YLED_Pin, GPIO_PIN_RESET);
                    HAL_GPIO_WritePin(GPIOB, RLED_Pin, GPIO_PIN_SET);
                    remainingTime = 15;
                    currentState = 0;
                    break;
            }
        }		
}



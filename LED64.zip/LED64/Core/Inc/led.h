#ifndef _LED_H
#define _LED_H
#include "main.h"

#define RLED_Pin GPIO_PIN_3
#define YLED_Pin GPIO_PIN_4
#define GLED_Pin GPIO_PIN_5

#define RLED1_Pin GPIO_PIN_12
#define YLED2_Pin GPIO_PIN_13
#define GLED3_Pin GPIO_PIN_14

#define LED_GPIO_Port GPIOB

void Led_ON(void);
//Led��ʼ��
void Led_Init(GPIO_TypeDef *GPIOLed);

#endif
